#include "queue.h"

//キューの確保,初期化,
int QueueAlloc(Queue *q, int max){
  q->front = 0;

  if((q->que = calloc(max,sizeof(int))) == NULL) {
    q->max = 0;
    return (-1);
  }
  q->max = max;
  return(0);
}

//キューの解放,破棄
void QueueFree(Queue *q){
  if(q->que != NULL){
    free(q->que);
  }
}

//キューにデータの追加
int QueueEnque(Queue *q, int x){
  q->front = (q->front+1) % q->max;
  if(QueueIsFull(q) == 1){
    printf("キューが満杯です\n");
    return(-1);
  }
  q->que[q->front] = x;
  return(0);
}

//キューのデータの削除
int QueueDeque(Queue *q, int *x){
  if(QueueIsEnpty(q) == 1){
    printf("キューが空です\n");
    return(-1);
  }

  *x = q->que[q->rear];
  q->rear = (q->rear+1) % q->max;
  return(0);
}

//キューの大きさを返す
int QueueSize(const Queue *q){
  return(q->max);
}

//キューのデータ数を返す
int QueueNo(const Queue *q){
  return(q->front - q->rear);
}

//キューが空か否かを返す
int QueueIsEnpty(const Queue *q){

  int exist = 0;
  if(q->front == q->rear){
    exist = 1; //空なら1を代入
  }

  return exist;
}

//キューが満杯か否かを返す
int QueueIsFull(const Queue *q){
  int full = 0;

  //(例外)frontがmaxならrearが0のとき満杯
  if(q->front == q->max){
    if(q->rear == 0){
      full = 1; //満杯なら１を代入
    }
  }else{
    if(q->front == q->rear-1){
      full = 1;
    }
  }

  return full;
}

//キューの状態を表示
void printq(const Queue *q){
  int i = 0;
  printf("現在の列\n");
  while(q->front != q->rear+i){
    printf("  %d  ",q->que[q->rear+i]);
    i = (i+1) % q->max;
  }
}
