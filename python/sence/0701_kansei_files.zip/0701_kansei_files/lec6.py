# -*- coding: utf-8 -*-
"""
Created on Mon Apr 22 17:47:04 2019

@author: taguchi
"""
import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as stats
from mpl_toolkits.mplot3d import Axes3D

####################################
# CSVを読み込む関数
# filename : ファイル名
# f_skip_first_row : １行目を読み飛ばすならTrue
# f_skip_first_col : １列目を読み飛ばすならTrue
####################################    
def loadCSV(filename,f_skip_first_row = False,f_skip_first_col=False):
    _skiprows = 0

    if f_skip_first_row==True:
        _skiprows = 1
        
    d = np.loadtxt(filename,delimiter=',',skiprows=_skiprows)
    

    if f_skip_first_col==True:
        d = d[:,1:]

    return d

####################################
# 散布図を描画する関数
# x,y: データ
# xlabel : x軸のラベル
# ylabel : y軸のラベル
####################################
def drawScatter1(x,y,xlabel,ylabel):     
    plt.clf();

    # グラフの軸ラベル等の設定
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.grid(True)

    # 散布図を描画
    for (i,j,k) in zip(x,y,range(1,x.shape[0]+1)):
        plt.plot(i,j,'ro')
        plt.annotate(k, xy=(i, j))
    plt.show()

####################################
# 散布図と直線を描画する関数
# x,y: プロットするデータ
# xlabel : x軸のラベル
# ylabel : y軸のラベル
# lx,ly: 直線のデータ    
####################################
def drawScatter2(x,y,xlabel,ylabel,lx,ly):     
    plt.clf();

    # グラフの軸ラベル等の設定
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.grid(True)

    # 散布図を描画
    for (i,j,k) in zip(x,y,range(1,x.shape[0]+1)):
        plt.plot(i,j,'ro')
        plt.annotate(k, xy=(i, j))
    plt.plot(lx, ly,color='red')
    plt.show()


####################################
# 散布図と回帰平面を3Dで描画する関数
# x,y,z: プロットするデータ
# xlabel : x軸のラベル
# ylabel : y軸のラベル
# zlabel : z軸のラベル
# lx,ly,lz: 平面のデータ    
####################################
def drawScatter3D(x,y,z,xlabel,ylabel,zlabel,lx,ly,lz):     
    plt.clf();
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    ax.scatter(x, y, z,color = (1,0,0))
    ax.plot_surface(lx, ly, lz, alpha = 0.5, color = (0,1,0),shade=False)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_zlabel(zlabel)
    plt.savefig("lecture6.png")
    plt.show()
    
####################################
# メイン関数
####################################    
if __name__ == "__main__":
    print("lecture 6")
    
    fn = "data6-1_p061(SJIS)"
    #fn = "data6-2_p086(SJIS)"
    
    data = loadCSV(fn + ".csv",True,True)

    print("data\n",data)
    
    x = data[:,:2]
    y = data[:,2]
    
    print("x\n",x)
    print("y\n",y)
    
    
    #サンプルとしてyの平均を通るx1-x2平面と平行な平面を作成
    y_m = np.average(y,axis=0)
    B = np.array([y_m,0,0])    
    print("B\n",B)

    # 格子状のデータを作成
    lx1, lx2 = np.meshgrid(np.arange(20, 90, 10), np.arange(0, 40, 10))
    print("lx1\n",lx1)
    print("lx2\n",lx2)
    
    ly = B[0] + B[1]*lx1 + B[2]*lx2 
    print("ly\n",ly)
        
    #dataのプロットと，平面を描画
    drawScatter3D(x[:,0],x[:,1],y[:],"x1","x2","y",lx1,lx2,ly)
    

